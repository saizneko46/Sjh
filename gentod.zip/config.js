/*          Ubah Token Dan OwnerId
           FLOIDS INFINITY GENERASI 2
*/
//==========================================
module.exports = {
  Token: "7852148401:AAFdd4GVhpfpUpOqzWnxT-dbcuybvpLgny8", 
  OwnerID: "6810074747", 
};
